package com.example.autocallmanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Covers the two pure decision functions CallExecutionManager exposes as
 * `internal`: classifyCallEnd (OFFHOOK-duration-based outcome) and
 * retryDelaySecondsFor (Smart Retry Engine 2.0 policy).
 *
 * What this file deliberately does NOT test: attemptCount incrementing
 * (CallReceiver.handleCallAttempt), actual retry scheduling (CallScheduler /
 * AlarmManager), and end-to-end finalizeAttempt/finishFromIdle. Those all
 * require a real or faked Android Context (SharedPreferences, AlarmManager,
 * TelecomManager), which this module's plain-JUnit test setup has no way to
 * provide -- there is no Robolectric or Mockito dependency here (see
 * app/build.gradle.kts: testImplementation is JUnit only). Covering those
 * paths for real would need one of those added, which is a call for the
 * project owner, not something to add silently as part of this fix.
 */
class CallExecutionManagerTest {

    // ---- classifyCallEnd -----------------------------------------------
    // Only three outcomes are distinguishable from OFFHOOK + duration alone;
    // see the KDoc on classifyCallEnd for why busy/no-answer/unreachable/
    // restricted aren't split out further.

    @Test
    fun neverOffhookIsNotAConnection() {
        val outcome = CallExecutionManager.classifyCallEnd(
            sawOffhook = false,
            offhookDurationMs = 0L
        )
        assertEquals("CALL_ENDED_WITHOUT_OFFHOOK", outcome.code)
        assertFalse(outcome.success)
    }

    @Test
    fun briefOffhookBelowThresholdIsNotTreatedAsConnected() {
        // Covers busy / instantly-declined / dropped-before-pickup: all look
        // identical on this platform (a short OFFHOOK blip), so one case
        // stands in for all of them.
        val outcome = CallExecutionManager.classifyCallEnd(
            sawOffhook = true,
            offhookDurationMs = CallExecutionManager.MIN_CONNECTED_OFFHOOK_MS - 1
        )
        assertEquals("CALL_OFFHOOK_TOO_BRIEF", outcome.code)
        assertFalse(outcome.success)
    }

    @Test
    fun offhookAtExactlyTheThresholdCountsAsConnected() {
        val outcome = CallExecutionManager.classifyCallEnd(
            sawOffhook = true,
            offhookDurationMs = CallExecutionManager.MIN_CONNECTED_OFFHOOK_MS
        )
        assertEquals("CALL_OFFHOOK_ENDED", outcome.code)
        assertTrue(outcome.success)
    }

    @Test
    fun offhookWellPastThresholdCountsAsConnected() {
        // Stands in for both "remote hung up after connecting" and "local
        // hung up after connecting" -- indistinguishable with this signal.
        val outcome = CallExecutionManager.classifyCallEnd(
            sawOffhook = true,
            offhookDurationMs = CallExecutionManager.MIN_CONNECTED_OFFHOOK_MS * 10
        )
        assertEquals("CALL_OFFHOOK_ENDED", outcome.code)
        assertTrue(outcome.success)
    }

    @Test
    fun zeroDurationOffhookIsNotConnectedEvenIfFlagIsSet() {
        // Defensive case: sawOffhook true but no timestamp captured (should
        // not happen in practice, but must not default to "connected").
        val outcome = CallExecutionManager.classifyCallEnd(
            sawOffhook = true,
            offhookDurationMs = 0L
        )
        assertEquals("CALL_OFFHOOK_TOO_BRIEF", outcome.code)
        assertFalse(outcome.success)
    }

    // ---- retryDelaySecondsFor -------------------------------------------

    @Test
    fun structuralFailuresAreNotRetried() {
        val permanent = listOf(
            "INVALID_NUMBER",
            "CALL_NOT_PERMITTED",
            "SIM_ACCOUNT_UNAVAILABLE",
            "SIM_ACCOUNT_INVALID",
            "SECURITY_ERROR"
        )
        for (code in permanent) {
            assertEquals(
                "$code should not be retried",
                Long.MAX_VALUE,
                CallExecutionManager.retryDelaySecondsFor(code, 300)
            )
        }
    }

    @Test
    fun newOffhookTooBriefCodeIsRetryable() {
        assertEquals(
            300L,
            CallExecutionManager.retryDelaySecondsFor("CALL_OFFHOOK_TOO_BRIEF", 300)
        )
    }

    @Test
    fun knownTransientCodesUseTheConfiguredInterval() {
        val transient = listOf(
            "CALL_NO_ANSWER",
            "CALL_NO_ANSWER_TIMEOUT",
            "DEVICE_CALL_BUSY",
            "CALL_BLOCKED_ACTIVE_CALL",
            "CALL_ENDED_WITHOUT_CONNECT",
            "CALL_ENDED_WITHOUT_OFFHOOK",
            "CALL_RESULT_TIMEOUT",
            "CALL_REQUEST_FAILED",
            "TELECOM_UNAVAILABLE",
            "AI_VOICE_REQUEST_FAILED",
            "CALL_STATE_TRACKING_FAILED",
            "SCHEDULE_FAILED"
        )
        for (code in transient) {
            assertEquals(
                "$code should retry after the configured interval",
                180L,
                CallExecutionManager.retryDelaySecondsFor(code, 180)
            )
        }
    }

    @Test
    fun unrecognizedCodeFallsBackToConfiguredIntervalRatherThanGuessing() {
        assertEquals(
            300L,
            CallExecutionManager.retryDelaySecondsFor("SOME_FUTURE_CODE_NOT_YET_CLASSIFIED", 300)
        )
    }

    @Test
    fun customRetryIntervalsAreHonoredExactlyNotScaled() {
        assertEquals(45L, CallExecutionManager.retryDelaySecondsFor("CALL_NO_ANSWER", 45))
        assertEquals(900L, CallExecutionManager.retryDelaySecondsFor("CALL_NO_ANSWER", 900))
    }

    @Test
    fun nonPositiveConfiguredIntervalIsFlooredToOneSecond() {
        assertEquals(1L, CallExecutionManager.retryDelaySecondsFor("CALL_NO_ANSWER", 0))
        assertEquals(1L, CallExecutionManager.retryDelaySecondsFor("CALL_NO_ANSWER", -30))
    }
}
