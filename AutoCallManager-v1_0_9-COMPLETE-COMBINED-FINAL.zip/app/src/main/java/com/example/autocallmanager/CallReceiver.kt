package com.example.autocallmanager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * Exact-alarm execution entry point. It never launches an Activity, so the
 * scheduled call can be requested while the device is screen-off or locked.
 *
 * Every real firing of ACTION_CALL_ATTEMPT is logged to ExecutionTraceStore
 * under one executionId shared by every stage of that attempt (including the
 * later phone-state broadcast handled in CallExecutionManager), so a failure
 * can be pinpointed to an exact stage after the fact -- see Diagnostics ->
 * Execution Trace. This is the same code path used by real schedules AND by
 * Diagnostics -> Run Background Test; the test is not a simulation.
 */
class CallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(CallScheduler.EXTRA_TASK_ID, -1L)
        if (taskId <= 0L) {
            ExecutionTraceStore.log(
                context, taskId, "", 0,
                ExecutionTraceStore.Stage.RECEIVER_STARTED, ExecutionTraceStore.FAIL,
                "invalid/missing EXTRA_TASK_ID (received $taskId) action=${intent.action}"
            )
            return
        }

        val isCallAttempt = intent.action == CallScheduler.ACTION_CALL_ATTEMPT
        val attempt = if (isCallAttempt) {
            (TaskStore.load(context).firstOrNull { it.id == taskId }?.attemptCount ?: 0) + 1
        } else 0
        val executionId = if (isCallAttempt) ExecutionTraceStore.newExecutionId(taskId, attempt) else ""

        if (isCallAttempt) {
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.ALARM_DELIVERED, ExecutionTraceStore.PASS,
                "action=${intent.action}"
            )
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.RECEIVER_STARTED, ExecutionTraceStore.PASS
            )
        }

        val pendingResult = goAsync()
        val wakeLock = acquireExecutionWakeLock(context)
        if (isCallAttempt) {
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.WAKELOCK_ACQUIRED,
                if (wakeLock != null) ExecutionTraceStore.PASS else ExecutionTraceStore.FAIL,
                if (wakeLock == null) "PowerManager.newWakeLock threw" else ""
            )
        }

        try {
            when (intent.action) {
                CallScheduler.ACTION_PRE_NOTIFICATION -> handlePreNotification(context, taskId)
                CallScheduler.ACTION_CALL_ATTEMPT -> handleCallAttempt(context, taskId, executionId, attempt)
                CallScheduler.ACTION_CALL_WATCHDOG -> CallExecutionManager.handleWatchdogTimeout(context, taskId)
            }
        } finally {
            runCatching { if (wakeLock?.isHeld == true) wakeLock.release() }
            pendingResult.finish()
        }
    }

    private fun handlePreNotification(context: Context, taskId: Long) {
        val task = TaskStore.load(context).firstOrNull { it.id == taskId } ?: return
        if (task.status == "Scheduled" && task.notificationEnabled && task.notifyBefore) {
            CallManager.showPreNotification(context, task)
            TaskStore.addHistory(context, task, "NOTIFICATION", "PRE_EVENT_NOTIFICATION")
        }
    }

    private fun handleCallAttempt(context: Context, taskId: Long, executionId: String, attempt: Int) {
        val tasks = TaskStore.load(context)
        val task = tasks.firstOrNull { it.id == taskId } ?: run {
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.CALL_EXECUTION_BEGIN, ExecutionTraceStore.FAIL,
                "no task found for id=$taskId"
            )
            return
        }

        if (SettingsStore.pausedAll(context) || task.status != "Scheduled") {
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.CALL_EXECUTION_BEGIN, ExecutionTraceStore.FAIL,
                if (SettingsStore.pausedAll(context)) "all schedules paused" else "task.status=${task.status}, expected Scheduled"
            )
            return
        }

        val now = System.currentTimeMillis()
        if (task.nextTrigger > 0L && task.nextTrigger > now + 60_000L) {
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.CALL_EXECUTION_BEGIN, ExecutionTraceStore.FAIL,
                "stale alarm ignored - nextTrigger is more than 60s in the future (task was likely rescheduled)"
            )
            return
        }

        task.liveStatus = "ALARM_DELIVERED"
        task.lastResult = "ALARM_DELIVERED"
        TaskStore.addHistory(context, task, "SYSTEM", "ALARM_DELIVERED")

        if (task.notifyAt && task.notificationEnabled) {
            CallManager.showNotification(
                context,
                task,
                "Scheduled event started • Attempt ${task.attemptCount + 1}/${task.maxAttempts}"
            )
            TaskStore.addHistory(context, task, "NOTIFICATION", "AT_EVENT_NOTIFICATION")
        }

        task.attemptCount = (task.attemptCount + 1).coerceAtMost(task.maxAttempts)
        task.status = "Running"
        task.nextTrigger = -1L
        task.liveStatus = "CALL_STARTING"
        task.lastResult = "CALL_STARTING"
        TaskStore.save(context, tasks)

        if (!task.callEnabled) {
            CallExecutionManager.completeWithoutCall(context, task)
            return
        }

        val active = CallExecutionStore.get(context)
        if (active != null && task.executionMode == "NORMAL_SIM") {
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.CALL_EXECUTION_BEGIN, ExecutionTraceStore.FAIL,
                "another execution already active for task ${active.taskId}"
            )
            CallExecutionManager.handleImmediateFailure(context, task, "CALL_BLOCKED_ACTIVE_CALL", executionId)
            return
        }

        if (task.executionMode == "AI_VOICE") {
            val voice = AiVoiceCallClient.create(context, task)
            val latestTasks = TaskStore.load(context)
            val latestTask = latestTasks.firstOrNull { it.id == taskId } ?: return
            if (!voice.ok) {
                latestTask.liveStatus = "AI_VOICE_REQUEST_FAILED"
                latestTask.lastResult = "AI_VOICE_REQUEST_FAILED"
                TaskStore.addHistory(context, latestTask, "AI_VOICE", voice.message)
                TaskStore.save(context, latestTasks)
                CallExecutionManager.handleImmediateFailure(context, latestTask, "AI_VOICE_REQUEST_FAILED", executionId)
                return
            }
            latestTask.liveStatus = "AI_VOICE_REQUESTED"
            latestTask.lastResult = "AI_VOICE_REQUESTED"
            TaskStore.addHistory(context, latestTask, "AI_VOICE", "AI_VOICE_REQUESTED${if (voice.executionId.isNotBlank()) " · ${voice.executionId}" else ""}")
            TaskStore.save(context, latestTasks)
            return
        }

        // Start background state tracking before asking Telecom to place the call.
        // This avoids losing a very fast RINGING/OFFHOOK transition.
        if (!CallExecutionManager.beginAttempt(context, task, executionId)) {
            ExecutionTraceStore.log(
                context, taskId, executionId, attempt,
                ExecutionTraceStore.Stage.CALL_EXECUTION_BEGIN, ExecutionTraceStore.FAIL,
                "beginAttempt() returned false (watchdog scheduling failed or conflicting active call)"
            )
            CallExecutionManager.handleImmediateFailure(context, task, "CALL_STATE_TRACKING_FAILED", executionId)
            return
        }
        ExecutionTraceStore.log(
            context, taskId, executionId, attempt,
            ExecutionTraceStore.Stage.CALL_EXECUTION_BEGIN, ExecutionTraceStore.PASS
        )

        val callResult = CallManager.placeCallDetailed(
            context = context,
            number = task.number,
            phoneAccountComponent = if (task.simSelectionEnabled) task.phoneAccountComponent else "",
            phoneAccountId = if (task.simSelectionEnabled) task.phoneAccountId else "",
            taskId = taskId,
            executionId = executionId,
            attempt = attempt
        )

        if (!callResult.ok) {
            CallManager.showCallError(context, callResult.message)
            CallExecutionManager.handleImmediateFailure(context, task, callResult.code, executionId)
            return
        }

        // Re-load after placeCall(): a very fast OFFHOOK/IDLE broadcast can update
        // the task concurrently. Never overwrite those newer states with the
        // stale task/list captured before the Telecom request.
        val latestTasks = TaskStore.load(context)
        val latestTask = latestTasks.firstOrNull { it.id == taskId } ?: return
        latestTask.liveStatus = "CALL_REQUEST_SENT"
        latestTask.lastResult = "CALL_REQUEST_SENT"
        TaskStore.addHistory(context, latestTask, "CALL", "CALL_REQUEST_SENT")
        TaskStore.save(context, latestTasks)

        startVoiceIfEnabled(context, latestTasks, latestTask)
        if (latestTask.messageEnabled && latestTask.messageText.isNotBlank()) {
            TaskStore.addHistory(context, latestTask, "MESSAGE", "MESSAGE_READY")
        } else {
            TaskStore.addHistory(context, latestTask, "MESSAGE", "MESSAGE_DISABLED")
        }
        TaskStore.save(context, latestTasks)
    }

    private fun startVoiceIfEnabled(context: Context, tasks: MutableList<CallTask>, task: CallTask) {
        if (!task.voiceEnabled || task.messageText.isBlank()) return
        task.liveStatus = "VOICE_STARTING"
        task.lastResult = "VOICE_SCHEDULED"
        TaskStore.addHistory(context, task, "VOICE", "VOICE_SCHEDULED")
        val serviceIntent = Intent(context, VoiceService::class.java).apply {
            putExtra(VoiceService.EXTRA_MESSAGE, task.messageText)
            putExtra(VoiceService.EXTRA_TASK_ID, task.id)
            putExtra(VoiceService.EXTRA_LANGUAGE, task.voiceLanguage)
            putExtra(VoiceService.EXTRA_SPEED, task.voiceSpeed)
            putExtra(VoiceService.EXTRA_PITCH, task.voicePitch)
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {
            task.liveStatus = "VOICE_START_FAILED"
            task.lastResult = "VOICE_START_FAILED"
            TaskStore.addHistory(context, task, "VOICE", "VOICE_START_FAILED")
            TaskStore.save(context, tasks)
        }
    }

    /** Returns null (never throws) so the caller can log an honest WAKELOCK_ACQUIRED FAIL instead of crashing the receiver. */
    private fun acquireExecutionWakeLock(context: Context): PowerManager.WakeLock? = runCatching {
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        power.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "${context.packageName}:AutoCallExecution"
        ).apply {
            setReferenceCounted(false)
            acquire(15_000L)
        }
    }.getOrNull()
}
