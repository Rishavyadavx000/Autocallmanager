package com.example.autocallmanager

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/** Starts a server-originated AI Voice Call. The server/telephony provider owns
 * the telephone audio path; Android never attempts to inject TTS into a SIM call. */
object AiVoiceCallClient {
    data class Result(val ok: Boolean, val message: String, val executionId: String = "")

    fun create(context: Context, task: CallTask): Result {
        val baseUrl = SettingsStore.adminCatalogUrl(context).trim().trimEnd('/')
        if (baseUrl.isBlank()) return Result(false, "AI Voice backend URL is not configured")
        return try {
            val conn = (URL("$baseUrl/v1/voice/calls").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 7000
                readTimeout = 12000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
                val key = SettingsStore.adminCatalogAppKey(context)
                if (key.isNotBlank()) setRequestProperty("X-App-Key", key)
            }

            val payload = JSONObject().apply {
                put("phoneNumber", task.number)
                put("scheduleEnabled", task.callEnabled)
                put("scheduleId", task.id.toString())
                put("promptId", task.promptId)
                put("promptVersion", task.promptVersion)
                put("instruction", task.messageText)
                put("maxDurationSeconds", 120)
            }.toString()

            conn.outputStream.use { it.write(payload.toByteArray(StandardCharsets.UTF_8)) }
            val code = conn.responseCode
            val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            conn.disconnect()

            val json = runCatching { JSONObject(body) }.getOrNull()
            if (code !in 200..299) {
                return Result(false, json?.optString("error").orEmpty().ifBlank { "AI Voice backend returned HTTP $code" })
            }
            val executionId = json?.optString("executionId", json.optJSONObject("call")?.optString("executionId", "")) ?: ""
            Result(true, "AI Voice call requested", executionId)
        } catch (e: Exception) {
            Result(false, e.message ?: "AI Voice backend request failed")
        }
    }
}
