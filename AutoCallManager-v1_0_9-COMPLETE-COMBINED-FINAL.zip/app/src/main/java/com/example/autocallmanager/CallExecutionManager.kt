package com.example.autocallmanager

import android.content.Context

/**
 * Finalizes an outgoing call attempt from real telephony state transitions.
 * Retry is scheduled only after a failed attempt, never immediately after
 * placeCall() succeeds.
 *
 * Every state transition here is also written to ExecutionTraceStore under
 * the executionId that CallReceiver generated when the alarm fired, so a
 * call outcome can be traced back to the exact background pipeline run that
 * produced it -- see Diagnostics -> Execution Trace.
 */
object CallExecutionManager {
    private const val CALL_WATCHDOG_MS = 120_000L

    /**
     * Minimum time OFFHOOK must hold before an attempt is treated as a real
     * connection. Android's legacy TelephonyManager call state (the only
     * signal available here without registering as an InCallService /
     * default dialer -- see CallStateManager) collapses dialing, ring-out,
     * an active call, and on-hold into one OFFHOOK value, so a call that
     * was instantly declined, busy, or dropped can still flash OFFHOOK
     * briefly. This is a heuristic, not a platform guarantee: it cannot
     * tell a real human answering from voicemail answering, and the exact
     * cutoff is a judgment call, not a measured constant. Tune it if real
     * call data suggests a better value.
     */
    internal const val MIN_CONNECTED_OFFHOOK_MS = 6_000L

    fun beginAttempt(context: Context, task: CallTask, executionId: String = ""): Boolean {
        val existing = CallExecutionStore.get(context)
        if (existing != null && existing.taskId != task.id) return false
        CallExecutionStore.start(context, task.id, task.attemptCount, executionId)
        return CallScheduler.scheduleCallWatchdog(
            context,
            task.id,
            System.currentTimeMillis() + CALL_WATCHDOG_MS
        )
    }

    fun handleImmediateFailure(context: Context, task: CallTask, code: String, executionId: String = "") {
        CallScheduler.cancelWatchdog(context, task.id)
        CallExecutionStore.clear(context)
        val tasks = TaskStore.load(context)
        val current = tasks.firstOrNull { it.id == task.id } ?: return
        current.liveStatus = code
        current.lastResult = code
        TaskStore.addHistory(context, current, "CALL_STATE", code)
        ExecutionTraceStore.log(
            context, task.id, executionId, task.attemptCount,
            ExecutionTraceStore.Stage.FINAL_OUTCOME, ExecutionTraceStore.FAIL, code
        )
        finalizeAttempt(context, tasks, current, success = false)
    }


    fun completeWithoutCall(context: Context, task: CallTask) {
        val tasks = TaskStore.load(context)
        val current = tasks.firstOrNull { it.id == task.id } ?: return
        current.liveStatus = "CALL_SKIPPED"
        current.lastResult = "CALL_SKIPPED"
        TaskStore.addHistory(context, current, "CALL", "CALL_SKIPPED")
        completeOrScheduleNext(context, tasks, current)
        notifyAfter(context, current, "Schedule processed without a cellular call")
    }

    fun handleWatchdogTimeout(context: Context, taskId: Long) {
        val active = CallExecutionStore.get(context) ?: return
        if (active.taskId != taskId) return

        // An ongoing off-hook/dialing call can legitimately last longer than
        // the watchdog window. Keep tracking it rather than falsely retrying.
        if (active.sawOffhook) {
            ExecutionTraceStore.log(
                context, taskId, active.executionId, active.attempt,
                ExecutionTraceStore.Stage.CALL_STATE_CALLBACK, ExecutionTraceStore.INFO,
                "watchdog extended - call still off-hook"
            )
            CallScheduler.scheduleCallWatchdog(
                context,
                taskId,
                System.currentTimeMillis() + CALL_WATCHDOG_MS
            )
            updateTaskState(context, taskId, "CALL_OFFHOOK_LONG_RUNNING")
            return
        }

        ExecutionTraceStore.log(
            context, taskId, active.executionId, active.attempt,
            ExecutionTraceStore.Stage.FINAL_OUTCOME, ExecutionTraceStore.FAIL,
            "CALL_RESULT_TIMEOUT - no off-hook observed within ${CALL_WATCHDOG_MS}ms"
        )
        CallExecutionStore.clear(context)
        CallScheduler.cancelWatchdog(context, taskId)

        val tasks = TaskStore.load(context)
        val task = tasks.firstOrNull { it.id == taskId } ?: return
        task.liveStatus = "CALL_RESULT_TIMEOUT"
        task.lastResult = "CALL_RESULT_TIMEOUT"
        TaskStore.addHistory(context, task, "CALL_STATE", task.liveStatus)
        finalizeAttempt(context, tasks, task, success = false)
    }

    fun onTelephonyState(context: Context, state: CallStateManager.State) {
        val active = CallExecutionStore.get(context) ?: return
        when (state) {
            CallStateManager.State.RINGING ->
                ExecutionTraceStore.log(
                    context, active.taskId, active.executionId, active.attempt,
                    ExecutionTraceStore.Stage.CALL_STATE_CALLBACK, ExecutionTraceStore.INFO,
                    "RINGING (incoming-call state, not used for outgoing tracking)"
                )
            CallStateManager.State.OFFHOOK -> {
                ExecutionTraceStore.log(
                    context, active.taskId, active.executionId, active.attempt,
                    ExecutionTraceStore.Stage.CALL_STATE_CALLBACK, ExecutionTraceStore.PASS,
                    "OFFHOOK observed"
                )
                CallExecutionStore.markOffhook(context)
                updateTaskState(context, active.taskId, "CALL_OFFHOOK")
            }
            CallStateManager.State.IDLE -> {
                // Ignore an immediate transient IDLE generated before Telecom
                // has established the outgoing call state.
                if (active.startedAt > 0L && System.currentTimeMillis() - active.startedAt < 1500L) {
                    ExecutionTraceStore.log(
                        context, active.taskId, active.executionId, active.attempt,
                        ExecutionTraceStore.Stage.CALL_STATE_CALLBACK, ExecutionTraceStore.INFO,
                        "IDLE ignored - within 1500ms startup guard window"
                    )
                    return
                }
                finishFromIdle(context, active)
            }
            CallStateManager.State.UNKNOWN ->
                ExecutionTraceStore.log(
                    context, active.taskId, active.executionId, active.attempt,
                    ExecutionTraceStore.Stage.CALL_STATE_CALLBACK, ExecutionTraceStore.INFO,
                    "UNKNOWN telephony state (READ_PHONE_STATE missing or query failed)"
                )
        }
    }

    private fun finishFromIdle(context: Context, active: CallExecutionStore.ActiveCall) {
        CallExecutionStore.clear(context)
        CallScheduler.cancelWatchdog(context, active.taskId)

        val tasks = TaskStore.load(context)
        val task = tasks.firstOrNull { it.id == active.taskId } ?: return

        val offhookDurationMs = if (active.sawOffhook && active.offhookAt > 0L) {
            (System.currentTimeMillis() - active.offhookAt).coerceAtLeast(0L)
        } else {
            0L
        }
        val outcome = classifyCallEnd(active.sawOffhook, offhookDurationMs)

        task.liveStatus = outcome.code
        task.lastResult = outcome.code
        TaskStore.addHistory(context, task, "CALL_STATE", "${outcome.code} (offhook_ms=$offhookDurationMs)")
        ExecutionTraceStore.log(
            context, active.taskId, active.executionId, active.attempt,
            ExecutionTraceStore.Stage.FINAL_OUTCOME,
            if (outcome.success) ExecutionTraceStore.PASS else ExecutionTraceStore.FAIL,
            "${outcome.code} (offhook_ms=$offhookDurationMs)"
        )
        finalizeAttempt(context, tasks, task, outcome.success)
    }

    /**
     * Outcome of a finished call attempt as a plain value, so classification
     * doesn't need a Context and can be unit tested directly.
     */
    internal data class CallEndOutcome(val code: String, val success: Boolean)

    /**
     * Pure classification of a finished attempt from the only two signals
     * available (see MIN_CONNECTED_OFFHOOK_MS): whether OFFHOOK was ever
     * observed, and how long it held before returning to IDLE.
     *
     * Only three outcomes are actually distinguishable with these signals:
     * - never went OFFHOOK at all
     * - went OFFHOOK only briefly (declined, dropped, busy, unanswered --
     *   these all look identical on this platform, see the class-level
     *   note on CallStateManager.State.OFFHOOK)
     * - OFFHOOK held long enough to be treated as a real connection (a
     *   remote hang-up after connecting looks the same as a local one --
     *   again indistinguishable with this signal set)
     *
     * This function does NOT invent finer labels (busy/no-answer/
     * unreachable/restricted) that the platform can't actually back up.
     */
    internal fun classifyCallEnd(sawOffhook: Boolean, offhookDurationMs: Long): CallEndOutcome =
        when {
            !sawOffhook -> CallEndOutcome("CALL_ENDED_WITHOUT_OFFHOOK", success = false)
            offhookDurationMs >= MIN_CONNECTED_OFFHOOK_MS -> CallEndOutcome("CALL_OFFHOOK_ENDED", success = true)
            else -> CallEndOutcome("CALL_OFFHOOK_TOO_BRIEF", success = false)
        }

    private fun updateTaskState(context: Context, taskId: Long, state: String) {
        val tasks = TaskStore.load(context)
        val task = tasks.firstOrNull { it.id == taskId } ?: return
        task.status = "Running"
        task.liveStatus = state
        task.lastResult = state
        TaskStore.save(context, tasks)
        TaskStore.addHistory(context, task, "CALL_STATE", state)
    }

    private fun finalizeAttempt(
        context: Context,
        tasks: MutableList<CallTask>,
        task: CallTask,
        success: Boolean
    ) {
        if (success) {
            // A successful call ends this attempt cycle. Move directly to the
            // next recurrence when configured, otherwise complete the task.
            completeOrScheduleNext(context, tasks, task)
            notifyAfter(context, task, "Call attempt completed after off-hook state")
            return
        }

        if (task.attemptCount < task.maxAttempts) {
            val retryDelaySeconds = retryDelaySecondsFor(task.lastResult, task.retryIntervalSeconds)
            if (retryDelaySeconds == Long.MAX_VALUE) {
                completeOrScheduleNext(context, tasks, task)
                notifyAfter(context, task, "Call failed • retry not appropriate")
                return
            }
            val retryAt = System.currentTimeMillis() + retryDelaySeconds * 1000L
            task.status = "Scheduled"
            task.nextTrigger = retryAt
            task.liveStatus = "WAITING_RETRY"
            task.lastResult = "RETRY_SCHEDULED"
            TaskStore.addHistory(context, task, "SYSTEM", "RETRY_SCHEDULED")
            TaskStore.save(context, tasks)
            if (CallScheduler.schedule(context, task.id, retryAt, task.attemptCount + 1)) {
                CallScheduler.schedulePreNotification(context, task)
                notifyAfter(context, task, "Call attempt failed • retry scheduled")
            } else {
                markSchedulerFailure(context, tasks, task)
            }
            return
        }

        completeOrScheduleNext(context, tasks, task)
        notifyAfter(context, task, "Maximum call attempts reached")
    }

    /**
     * Smart Retry Engine 2.0: outcome-aware retry delay in seconds, keyed off
     * the failure code the attempt just finished with (task.lastResult).
     *
     * Long.MAX_VALUE is a sentinel the caller already checks for (see
     * finalizeAttempt) meaning "do not retry this outcome at all" -- reserved
     * for outcomes that are structural rather than transient, i.e. they would
     * fail identically on every future attempt until the user changes
     * something (wrong number, missing call permission, disabled/invalid SIM
     * account).
     *
     * Every other outcome -- CALL_OFFHOOK_TOO_BRIEF (see classifyCallEnd),
     * busy, no-answer, timeout, and other temporary system/telecom errors --
     * retries after the task's own configured [baseIntervalSeconds], so a
     * user's custom retry delay is always honored exactly rather than being
     * scaled up or down. internal (not private) so it's directly unit
     * testable, same as classifyCallEnd.
     */
    internal fun retryDelaySecondsFor(lastResult: String, baseIntervalSeconds: Int): Long {
        val nonRetryable = setOf(
            "INVALID_NUMBER",
            "CALL_NOT_PERMITTED",
            "SIM_ACCOUNT_UNAVAILABLE",
            "SIM_ACCOUNT_INVALID",
            "SECURITY_ERROR"
        )
        if (lastResult in nonRetryable) return Long.MAX_VALUE

        // Busy (DEVICE_CALL_BUSY, CALL_BLOCKED_ACTIVE_CALL), no-answer
        // (CALL_NO_ANSWER, CALL_NO_ANSWER_TIMEOUT, CALL_ENDED_WITHOUT_CONNECT,
        // CALL_ENDED_WITHOUT_OFFHOOK), and temporary/system errors
        // (CALL_RESULT_TIMEOUT, CALL_REQUEST_FAILED, TELECOM_UNAVAILABLE,
        // AI_VOICE_REQUEST_FAILED, CALL_STATE_TRACKING_FAILED, SCHEDULE_FAILED,
        // and anything unrecognized) all fall through to the task's own
        // configured interval.
        return baseIntervalSeconds.toLong().coerceAtLeast(1L)
    }

    private fun completeOrScheduleNext(context: Context, tasks: MutableList<CallTask>, task: CallTask) {
        if (SettingsStore.pausedAll(context)) {
            task.status = "Paused"
            task.nextTrigger = -1L
            task.liveStatus = "PAUSED"
            task.lastResult = "PAUSED"
            TaskStore.addHistory(context, task, "SYSTEM", "PAUSED")
            TaskStore.save(context, tasks)
            return
        }

        // Diagnostic test tasks are one-shot by construction: they exist only
        // to prove the pipeline fired, and must never turn into a real
        // recurring schedule that keeps calling the test number.
        if (task.isDiagnosticTest) {
            task.status = "Stopped"
            task.nextTrigger = -1L
            TaskStore.save(context, tasks)
            return
        }

        val next = ScheduleCalculator.nextRecurring(task, System.currentTimeMillis())
        if (next != null) {
            task.attemptCount = 0
            task.activeSlotIndex += 1
            task.nextTrigger = next
            task.status = "Scheduled"
            task.liveStatus = "WAITING_NEXT_SLOT"
            task.lastResult = "NEXT_SLOT"
            TaskStore.addHistory(context, task, "SYSTEM", "NEXT_SLOT")
            TaskStore.save(context, tasks)
            if (CallScheduler.schedule(context, task.id, next, 1)) {
                CallScheduler.schedulePreNotification(context, task)
            } else {
                markSchedulerFailure(context, tasks, task)
            }
            return
        }

        task.status = "Stopped"
        task.nextTrigger = -1L
        task.liveStatus = if (task.lastResult == "CALL_OFFHOOK_ENDED") "COMPLETED" else "FAILED"
        task.lastResult = if (task.liveStatus == "COMPLETED") "COMPLETED" else "FAILED_MAX_ATTEMPTS"
        TaskStore.addHistory(context, task, "SYSTEM", task.lastResult)
        TaskStore.save(context, tasks)
    }

    private fun notifyAfter(context: Context, task: CallTask, message: String) {
        if (!task.notificationEnabled || !task.notifyAfter) return
        CallManager.showNotification(context, task, message)
        TaskStore.addHistory(context, task, "NOTIFICATION", "AFTER_ATTEMPT_NOTIFICATION")
    }

    private fun markSchedulerFailure(context: Context, tasks: MutableList<CallTask>, task: CallTask) {
        task.status = "Stopped"
        task.nextTrigger = -1L
        task.liveStatus = "SCHEDULER_ERROR"
        task.lastResult = "SCHEDULE_FAILED"
        TaskStore.addHistory(context, task, "SYSTEM", "SCHEDULE_FAILED")
        TaskStore.save(context, tasks)
    }
}
