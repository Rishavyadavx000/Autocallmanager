package com.example.autocallmanager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" -> {
                CallExecutionStore.clear(context)
                if (SettingsStore.pausedAll(context)) return
                TaskStore.load(context)
                    .filter { it.status == "Scheduled" && it.nextTrigger > System.currentTimeMillis() }
                    .forEach { task ->
                        if (CallScheduler.schedule(context, task.id, task.nextTrigger, task.attemptCount + 1)) {
                            CallScheduler.schedulePreNotification(context, task)
                        }
                    }
            }
        }
    }
}
