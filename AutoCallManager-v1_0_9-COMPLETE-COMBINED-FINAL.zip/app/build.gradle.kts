plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.autocallmanager"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.autocallmanager"
        minSdk = 26
        targetSdk = 35
        versionCode = 109
        versionName = "1.0.9"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    // ScheduleCalculator has no Android-framework dependency (only java.time), so its
    // tests run as plain JVM unit tests -- no emulator/device or Robolectric needed.
    testImplementation("junit:junit:4.13.2")
}
